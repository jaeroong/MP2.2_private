# Cranfield collection
This collection was obtained from
http://ir.dcs.gla.ac.uk/resources/test_collections/cran/ and is publicly
available.

The relevance judgments are non-binary, facilitating evaluation using NDCG.
Everything has been converted to MeTA line-corpus format. The original
relevance judgments include relevance values of `-1`, which are unexplained
in the original data's README. We have excluded these judgments from the
data provided here.
